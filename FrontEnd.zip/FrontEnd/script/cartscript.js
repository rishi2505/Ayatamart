let token = localStorage.getItem("token");
    axios.get('http://localhost:8080/ayatamart/cart/products',{headers:{
                'Content-type': 'application/json',
                token: token
            }}).then((completedata) => {
                let data1 = " ";
                let total=0;
                if(completedata.data.cartModelResponses == null){
                    data1 +=`<div class="cartlist">
                    <h2>Empty Cart</h2>
                    </div>`
                }
                else{

 for(let i=0; i<completedata.data.cartModelResponses.length;i++){
    total+=completedata.data.cartModelResponses[i].price;
  data1 +=`<div class="cartlist">
  <div class ="eid">
  
         <p class="image"><img src=${completedata.data.cartModelResponses[i].image} width="100" height="100"></p> </div>                      
          <p class="product_name">${completedata.data.cartModelResponses[i].productName}</p>  
          <label class="lqty">Quantity:</label>
          <p class="quantity">${completedata.data.cartModelResponses[i].quantity}                        
         <p class="price">₹${completedata.data.cartModelResponses[i].price}</p>      
    </div>`
  }
}
     document.getElementById("cartlist").innerHTML = data1
     document.getElementById("total").innerHTML=total
        })
    


document.getElementById("removelist").addEventListener("click", function (e) {
    e.preventDefault();
    axios.delete('http://localhost:8080/ayatamart/cart/products',{headers:{
                'Content-type': 'application/json',
                token: token
            }}).then((completedata)=>{
                 if (completedata.status == 204) {
                    alert('Cart is Empty')
                  window.location.href = "productlistingpage.html"
                } 
            })
})

document.getElementById("confirmOrder").addEventListener("click", function (e) {
    axios.post('http://localhost:8080/ayatamart/cart/products',{},{headers:{
        'Content-type': 'application/json',
        token: token
    }}).then((completedata)=>{
        console.log(completedata.status);
         if (completedata.status == 202) {
         window.location.href = "popup2.html"
      } 
   }).catch(error=>{
    if(error.response.status==400){
        alert('Cart is empty')
        window.location.href = "productlistingpage.html"
    }
    else{
        alert('Session Time Out')
        window.location.href = "index.html"
    }
   })
})