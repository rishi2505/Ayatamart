var form = document.getElementById("form")
form.addEventListener('submit', function (e) {
    e.preventDefault();
    var userName = document.getElementById('Uname').value;
    var password = document.getElementById("Pass").value;

    fetch('http://localhost:8080/ayatamart/users/login', {
        method: "POST",
        headers: {
            'Content-type': 'application/json'
        },
        body: JSON.stringify({
            username: userName,
            password: password

        })
    }).then((response) => {
        return response.json();

    }).then((newData) => {
        console.log(newData.status);
        if (newData.status == 'SUCCESS') {
            localStorage.setItem("token", newData.token);
            window.location.href = "productlistingpage.html"
        } else {
            document.getElementById("wronguser").innerHTML="Invalid Username or password"
        }
    })
})
