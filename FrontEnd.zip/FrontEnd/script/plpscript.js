let token = localStorage.getItem("token");
    headers= {
        'Content-type': 'application/json',
        token: token
    };
    axios.get('http://localhost:8080/ayatamart/products/list',{headers:{
                'Content-type': 'application/json',
                token: token
            }}).then((completedata) => {


   let data1 = " ";
    for(let i=0; i<completedata.data.products.length;i++){
     data1 +=`<div class="productslist">
      <p>
             <class="image"><img src=${completedata.data.products[i].image} width=200,height=250></p>             
              <class="product_id">${completedata.data.products[i].productId}            
              <class="product_name">${completedata.data.products[i].productName}</p>                              
             <class="price">${completedata.data.products[i].price}</p>      
                      
             <class="description">${completedata.data.products[i].description}</p>
          <button id=${completedata.data.products[i].productId}>Add to Cart</button> 
      </div>`
    }
    document.getElementById("productslist").innerHTML = data1
    }).catch(error=>{
        if(error.response.status==403){
            alert('Session Time Out')
            window.location.href = "index.html"
        }
       })
    
      
       axios.get('http://localhost:8080/ayatamart/products/user',{headers:{
        'Content-type': 'application/json',
        token: token
    }}).then((completedata) => {
let data2 = " ";
 data2 =`<div class="username">
 <p>Welcome
   <class="username">${completedata.data.employeeName}</p>           
</div>`
 document.getElementById("username").innerHTML = data2
})
  
     
