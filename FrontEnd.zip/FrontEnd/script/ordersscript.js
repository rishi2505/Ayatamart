let token = localStorage.getItem("token");
    axios.get('http://localhost:8080/ayatamart/orders',{headers:{
                'Content-type': 'application/json',
                token: token
            }}).then((completedata) => {
              console.log(completedata.data);

    let data1 = "";
   



    for(let i=0; i<completedata.data.orderModelResponses.length;i++){

    data1 += `<div class="cartlist">
            
            <div class ="eid">

            <p class="image"> <img src="${completedata.data.orderModelResponses[i].image}" width="50" height="60"> </p>
            </div>

            
             <p class="product_name">${completedata.data.orderModelResponses[i].productName}</p>

             <label class="l_orderid">Order Id:</label>

             <p class="orderid">${completedata.data.orderModelResponses[i].orderId}</p>

             <label class="l_productid">Product Id:</label>

            <p class="productid">${completedata.data.orderModelResponses[i].productId}</p>
            
            <label class="l_status">Status:</label>

            <p class="status">${completedata.data.orderModelResponses[i].status}</p>
           
            <label class="l_address">Address/Collect from:</label>

            <p class="address">${completedata.data.orderModelResponses[i].address}</p>
            
            <label class="ltotal">Total Amount:</label>

            <p class="total">${completedata.data.orderModelResponses[i].totalAmount}</p>



                   

     </div>`

    }

    document.getElementById("cartlist").innerHTML = data1;

}).catch(error=>{
    if(error.response.status==403){
        alert('Session Time Out')
        window.location.href = "index.html"
    }})

    axios.get('http://localhost:8080/ayatamart/products/user',{headers:{
        'Content-type': 'application/json',
        token: token
    }}).then((completedata) => {
let data2 = " ";
 data2 =`<div class="username">
 <p>Welcome
   <class="username">${completedata.data.employeeName}</p>           
</div>`
 document.getElementById("username").innerHTML = data2
})