package com.ayata.ayatamart.dto.request;

public class PlpRequest {
    private int productId;

    public PlpRequest() {
    }

    public PlpRequest(int productId) {
        this.productId = productId;
    }


}
