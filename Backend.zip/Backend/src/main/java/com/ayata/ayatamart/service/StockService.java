
package com.ayata.ayatamart.service;

import com.ayata.ayatamart.dto.request.StockRequest;

public interface StockService {
    public void updateStock(StockRequest request);
}

