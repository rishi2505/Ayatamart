package com.ayata.ayatamart.service;

import com.ayata.ayatamart.dto.request.UserRequest;
import com.ayata.ayatamart.dto.response.UserResponse;
import com.ayata.ayatamart.dto.response.UserRoleResponse;

public interface UserService {
    public UserResponse currentLoginStatus(UserRequest user);

    public UserRoleResponse isValidUser(String token);
}
