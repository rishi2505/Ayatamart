package com.ayata.ayatamart.dto.response;


import java.util.List;

public class PlpResponse {


    private List<ProductModelResponse> productModelResponse;

    public List<ProductModelResponse> getProductModelResponse() {
        return productModelResponse;
    }

    public void setProductModelResponse(List<ProductModelResponse> productModelResponse) {
        this.productModelResponse = productModelResponse;
    }
}
