package com.ayata.ayatamart.dto.constant;

public enum Status {
    SUCCESS,
    FAILURE
}

