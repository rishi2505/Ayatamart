package com.ayata.ayatamart;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AyataMartApplication {

    public static void main(String[] args) {
        SpringApplication.run(AyataMartApplication.class, args);
    }



}